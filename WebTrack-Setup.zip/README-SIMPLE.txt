WebTrack - Royal Canadian Mint stock watcher
============================================

INSTALL (one time, takes 15 seconds):

  1. Extract this ZIP anywhere  (right-click -> Extract All)
  2. Open the extracted folder and double-click  _INSTALL.bat
  3. A small window pops up with the coin link already filled in.
     Keep it (or paste a different mint.ca link) and click
     "Start watching".
  4. Done. You can delete the ZIP and the extracted folder.

WHAT IT DOES

  It checks the mint.ca page every 10 seconds, silently, in the
  background. The moment the item can be ordered:

    - a LOUD notification pops up and stays until you dismiss it
    - the product page opens in your browser -> buy it!

  The rest of the time you will never see or hear it. It keeps
  working after the computer restarts. It only pauses while the
  computer is asleep or turned off.

WATCH A DIFFERENT ITEM

  Open the Start Menu and click "WebTrack - change watched item",
  then paste the new mint.ca link. It replaces the old one -
  WebTrack always watches exactly what you last entered.

UNINSTALL

  Open the Start Menu and click "WebTrack - uninstall"
  (or double-click _UNINSTALL.bat). Everything is removed.

(The "app" folder holds the program files - you never need
 to open it.)
